var txt="Hello world";

function sayHello () {
    document.write(window.txt);
}
window.sayHello();